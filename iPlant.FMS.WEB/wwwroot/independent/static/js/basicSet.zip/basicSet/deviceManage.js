﻿require(['../static/utils/js/jquery-3.1.1', '../static/utils/js/base/base'], function ($yang, $com) {

    var HTML,
		model,
		PropertyField,
		KEYWORD,
		KEYWORD_PROPERTY,
		KEYWORD_LIST,
		KEYWORD_LIST_PROPERTY,
		DEFAULT_VALUE,
		DEFAULT_VALUE_PROPERTY,
		TypeSource,
		TypeSource_PROPERTY,
		FORMATTRT,
		FORMATTRT_PROPERTY,
		DMSDeviceSource,
		DMSDevicePropertySource;
    HTML = { 
        TableLedgerItemNode: [
			'<tr>',
			'<td style="width: 3px"><input type="checkbox"',
            '	class="femi-tb-checkbox" style="margin: 1px 0px 1px" /></td>',
            '<td   data-title="WID" data-value="{{WID}}" >{{WID}}</td>',
			'<td style="min-width: 50px;display:none" data-title="ID" data-value="{{ID}}"  >{{ID}}</td>	     ',
			'<td style="min-width: 50px" data-title="DeviceNo" data-value="{{DeviceNo}}"  >{{DeviceNo}}</td>    ',
			'<td style="min-width: 50px" data-title="DeviceName" data-value="{{DeviceName}}"  >{{DeviceName}}</td>    ',
			'<td style="min-width: 50px" data-title="WorkShopName" data-value="{{WorkShopName}}"  >{{WorkShopName}}</td>  ',
			'<td style="min-width: 50px" data-title="LineName" data-value="{{LineName}}"  >{{LineName}}</td> ',
			'<td style="min-width: 50px" data-title="DeviceTypeID" data-value="{{DeviceTypeID}}"  >{{DeviceTypeID}}</td>   ',
			'<td style="min-width: 50px" data-title="SupplierID" data-value="{{SupplierID}}"  >{{SupplierID}}</td>  ',
			'<td style="min-width: 50px" data-title="MachineTypeID" data-value="{{MachineTypeID}}"  >{{MachineTypeID}}</td>  ',
			'<td style="min-width: 50px" data-title="SystemID" data-value="{{SystemID}}"  >{{SystemID}}</td> ',
			'<td style="min-width: 50px" data-title="ControllerTypeID" data-value="{{ControllerTypeID}}"  >{{ControllerTypeID}}</td> ',
			'<td style="min-width: 50px" data-title="IP"				data-value="{{IP}}"   >{{IP}}</td>    ',
			'<td style="min-width: 50px" data-title="Price"  data-value="{{Price}}"   >{{Price}}</td>    ',
			'<td style="min-width: 50px" data-title="Depreciation" data-value="{{Depreciation}}"  >{{Depreciation}}</td>  ',
			'<td style="min-width: 50px" data-title="Status" 	data-value="{{Status}}" 	 >{{Status}}</td>   ',
			'<td style="min-width: 50px" data-title="Operator" 	data-value="{{Operator}}" 	 >{{Operator}}</td>    ',
			'<td style="min-width: 80px" data-title="EditTime" 	data-value="{{EditTime}}" 	 >{{EditTime}}</td>  ',
			'</tr>',
        ].join(""),
       TablePropertyItemNode: [
			'<tr>',
			'<td style="width: 3px"><input type="checkbox"    ',
			'	class="femi-tb-checkbox" style="margin: 1px 0px 1px" /></td> ',
            '<td   data-title="WID" data-value="{{WID}}" >{{WID}}</td>',
			'<td style="min-width: 50px;display:none" data-title="ID" data-value="{{ID}}"  >{{ID}}</td>	     ',
			'<td style="min-width: 50px" data-title="Name" data-value="{{Name}}">{{Name}}</td>    ',
			'<td style="min-width: 50px" data-title="Operator" data-value="{{Operator}}">{{Operator}}</td>   ',
			'<td style="min-width: 50px" data-title="EditTime" data-value="{{EditTime}}">{{EditTime}}</td> ',
			'<td style="min-width: 50px" data-title="Active" data-value="{Active}}">{{Active}}</td>  ',
			'</tr>',
        ].join(""),
    };


    PropertyField = ["Default", "SupplierID", "SystemID", "MachineTypeID", "ControllerTypeID", "DeviceTypeID"];
    DMSDeviceSource = [];
    DMSDevicePropertySource = [[], [], [], [], [], []];

    (function () {
        KEYWORD_LIST = [
			"DeviceNo|设备号",
			"DeviceName|名称",
			"WorkShopID|车间|ArrayOne",
			"LineID|产线|ArrayOne|workShopID",
			"DeviceTypeID|设备类型|ArrayOne",
			"SupplierID|供应商|ArrayOne",
			"MachineTypeID|机器型号|ArrayOne",
			"SystemID|系统|ArrayOne",
			"ControllerTypeID|控制器|ArrayOne",
			"IP|IP|IP",
			"Price|净值",
			"Depreciation|残值",
			"Status|状态|ArrayOne",
			"EditTime|录入时间|DateTime"
        ];
        FORMATTRT = {};
        KEYWORD = {};
        DEFAULT_VALUE = {
            DeviceNo: "",
            DeviceName: "",
            WorkShopID: 0,
            LineID: 0,
            DeviceTypeID: 0,
            SupplierID: 0,
            MachineTypeID: 0,
            SystemID: 0,
            ControllerTypeID: 0,
            IP: "",
            Price: 0,
            Depreciation: 0,
        };

        TypeSource = {
            WorkShopID: [{
                name: "全部",
                value: 0
            }],
            LineID: [{
                name: "全部",
                value: 0,
                far: 0
            }],
            DeviceTypeID: [],
            SupplierID: [],
            DeviceTypeID: [],
            MachineTypeID: [],
            SystemID: [],
            ControllerTypeID: [],
            Status: [{
                name: "未知",
                value: 0
            }, {
                name: "启用",
                value: 1
            }, {
                name: "保养",
                value: 2
            }, {
                name: "故障",
                value: 3
            }, {
                name: "报废",
                value: 4
            }]
        };
        $.each(KEYWORD_LIST, function (i, item) {
            var detail = item.split("|");
            KEYWORD[detail[0]] = {
                index: i,
                name: detail[1],
                type: detail.length > 2 ? detail[2] : undefined
            };
            if (detail.length > 2) {
                FORMATTRT[detail[0]] = $com.util.getFormatter(TypeSource, detail[0], detail[2]);
            }

        });

    })();

    (function () {
        KEYWORD_LIST_PROPERTY = [
			"Name|名称",
			"Active|状态|ArrayOne",
			"EditTime|编辑时刻|DateTime"
        ];
        FORMATTRT_PROPERTY = {};
        KEYWORD_PROPERTY = {};
        DEFAULT_VALUE_PROPERTY = {
            Name: "",
            Active: true
        };

        TypeSource_PROPERTY = {
            Active: [{
                name: "激活",
                value: true
            }, {
                name: "冻结",
                value: false
            }],
        };
        $.each(KEYWORD_LIST_PROPERTY, function (i, item) {
            var detail = item.split("|");
            KEYWORD_PROPERTY[detail[0]] = {
                index: i,
                name: detail[1],
                type: detail.length > 2 ? detail[2] : undefined
            };
            if (detail.length > 2) {
                FORMATTRT_PROPERTY[detail[0]] = $com.util.getFormatter(TypeSource_PROPERTY, detail[0], detail[2]);
            }

        });

    })();



    model = $com.Model.create({
        name: 'iPlant.MES',

        type: $com.Model.MAIN,

        configure: function () {
            this.run();

        },

        events: function () {

            $("body").delegate(".device_property", "click", function () {
                var $this = $(this),
					type = $this.attr("data-type");
                type = Number(type);
                $(".femi-bd-half-right").show();
                model._type = type;
                model.com.renderProerty(DMSDevicePropertySource[type]);
            });
            $("body").delegate(".device_property-empty", "click", function () {
                $(".femi-bd-half-right").hide();
            });
            $("body").delegate("#femi-search-text-ledger", "change", function () {
                var $this = $(this),
					value = $(this).val();
                if (value == undefined || value == "" || value.trim().length < 1)
                    $("#femi-ledger-tbody").children("tr").show();
                else
                    $com.table.filterByLikeString($("#femi-ledger-tbody"), DMSDeviceSource, value, "ID", FORMATTRT);
            });
            $("body").delegate("#femi-search-ledger", "click", function () {

                var default_value = {
                    WorkShopID: 0,
                    LineID: 0,
                    DeviceTypeID: 0,
                    SupplierID: 0,
                    MachineTypeID: 0,
                    SystemID: 0,
                    ControllerTypeID: 0
                };

                $("body").append($com.modal.show(default_value, KEYWORD, "查询", function (rst) {


                    if (!rst || $.isEmptyObject(rst))
                        return;

                    default_value.WorkShopID = Number(rst.WorkShopID);
                    default_value.WorkShopName = FORMATTRT.WorkShopID(Number(rst.WorkShopID));
                    default_value.LineID = Number(rst.LineID);
                    default_value.LineName = FORMATTRT.LineID(Number(rst.LineID));
                    default_value.DeviceTypeID = Number(rst.DeviceTypeID);
                    default_value.SupplierID = Number(rst.SupplierID);
                    default_value.MachineTypeID = Number(rst.MachineTypeID);
                    default_value.SystemID = Number(rst.SystemID);
                    default_value.ControllerTypeID = Number(rst.ControllerTypeID);


                    $com.table.filterByConndition($("#femi-ledger-tbody"), DMSDeviceSource, default_value, "ID");

                }, TypeSource));

            });

            $("body").delegate("#femi-add-ledger", "click", function () {

                //将Json数据中的数据值改成对应默认值，然后传入进去
                $("body").append($com.modal.show(DEFAULT_VALUE, KEYWORD, "新增", function (rst) {
                    //调用插入函数 

                    if (!rst || $.isEmptyObject(rst))
                        return;
                    var _data = {
                        ID: 0,
                        DeviceID: 0,
                        DeviceNo: rst.DeviceNo,
                        DeviceName: rst.DeviceName,
                        WorkShopID: Number(rst.WorkShopID),
                        WorkShopName: FORMATTRT.WorkShopID(Number(rst.WorkShopID)),
                        LineID: Number(rst.LineID),
                        LineName: FORMATTRT.LineID(Number(rst.LineID)),
                        DeviceTypeID: Number(rst.DeviceTypeID),
                        SupplierID: Number(rst.SupplierID),
                        MachineTypeID: Number(rst.MachineTypeID),
                        SystemID: Number(rst.SystemID),
                        ControllerTypeID: Number(rst.ControllerTypeID),
                        IP: rst.IP,
                        Price: Number(rst.Price),
                        Depreciation: Number(rst.Depreciation)
                    };
                    model.com.add({
                        data: _data
                    }, function (res) {
                        alert("新增成功");
                        model.com.refresh();
                    })

                }, TypeSource));

            });

            $("body").delegate("#femi-edit-ledger", "click", function () {

                var SelectData = $com.table.getSelectionData($("#femi-ledger-tbody"), 'ID', DMSDeviceSource);


                if (!SelectData || !SelectData.length) {
                    alert("请先选择一行数据再试！")
                    return;
                }
                if (SelectData.length != 1) {
                    alert("只能同时对一行数据修改！")
                    return;
                }

                var default_value = {
                    DeviceNo: SelectData[0].DeviceNo,
                    DeviceName: SelectData[0].DeviceName,
                    WorkShopID: SelectData[0].WorkShopID,
                    LineID: SelectData[0].LineID,
                    DeviceTypeID: SelectData[0].DeviceTypeID,
                    SupplierID: SelectData[0].SupplierID,
                    MachineTypeID: SelectData[0].MachineTypeID,
                    SystemID: SelectData[0].SystemID,
                    ControllerTypeID: SelectData[0].ControllerTypeID,
                    IP: SelectData[0].IP,
                    Price: SelectData[0].Price,
                    Depreciation: SelectData[0].Depreciation
                };

                $("body").append($com.modal.show(default_value, KEYWORD, "修改", function (rst) {
                    //调用修改函数
                    if (!rst || $.isEmptyObject(rst))
                        return;

                    SelectData[0].DeviceNo = rst.DeviceNo;
                    SelectData[0].DeviceName = rst.DeviceName;
                    SelectData[0].WorkShopID = Number(rst.WorkShopID);
                    SelectData[0].WorkShopName = FORMATTRT.WorkShopID(Number(rst.WorkShopID));
                    SelectData[0].LineID = Number(rst.LineID);
                    SelectData[0].LineName = FORMATTRT.LineID(Number(rst.LineID));
                    SelectData[0].DeviceTypeID = Number(rst.DeviceTypeID);
                    SelectData[0].SupplierID = Number(rst.SupplierID);
                    SelectData[0].MachineTypeID = Number(rst.MachineTypeID);
                    SelectData[0].SystemID = Number(rst.SystemID);
                    SelectData[0].ControllerTypeID = Number(rst.ControllerTypeID);
                    SelectData[0].IP = rst.IP;
                    SelectData[0].Price = Number(rst.Price);
                    SelectData[0].Depreciation = Number(rst.Depreciation);


                    model.com.add({
                        data: SelectData[0]
                    }, function (res) {
                        alert("修改成功");
                        model.com.refresh();
                    })

                }, TypeSource));
            });

            $("body").delegate("#femi-refresh-ledger", "click", function () {

                model.com.refresh();
            });
            $("body").delegate(".device_status", "click", function () {
                var $this = $(this),
					status = $this.attr("data-status"),
					text = $this.children().text().trim(),
					SelectData = $com.table.getSelectionData($("#femi-ledger-tbody"), 'ID', DMSDeviceSource);

                if (!SelectData || !SelectData.length) {
                    alert("至少选择一行数据！")
                    return;
                }

                if (!confirm("已选择" + SelectData.length + "条数据，确定将其改为" + text + "？")) {
                    return;
                }

                model.com.changeStatus({
                    data: SelectData,
                    status: status
                }, [function (res) {
                    alert(text + "成功");
                    model.com.refresh();
                }, function () {

                }])


            });

            $("body").delegate("#femi-add-property", "click", function () {
                //将Json数据中的数据值改成对应默认值，然后传入进去
                $("body").append($com.modal.show(DEFAULT_VALUE_PROPERTY, KEYWORD_PROPERTY, "新增属性", function (rst) {
                    //调用插入函数 

                    if (!rst || $.isEmptyObject(rst))
                        return;


                    var _data = {
                        ID: 0,
                        Name: rst.Name,
                        Active: false,
                        EditTime: new Date()
                    };
                    $.each(DMSDevicePropertySource[model._type], function (i, item) {
                        if (item.ID >= _data.ID)
                            _data.ID = item.ID + 1;
                    });
                    DMSDevicePropertySource[model._type].push(_data);

                    model.com.renderProerty(DMSDevicePropertySource[model._type]);

                }, TypeSource_PROPERTY));

            });
            $("body").delegate("#femi-edit-property", "click", function () {
                var SelectData = $com.table.getSelectionData($("#femi-ledger-property-tbody"), 'ID', DMSDevicePropertySource[model._type]);


                if (!SelectData || !SelectData.length) {
                    alert("请先选择一行数据再试！")
                    return;
                }
                if (SelectData.length != 1) {
                    alert("只能同时对一行数据修改！")
                    return;
                }

                var default_value = {
                    Name: SelectData[0].Name
                };

                $("body").append($com.modal.show(default_value, KEYWORD_PROPERTY, "修改属性", function (rst) {
                    //调用修改函数
                    if (!rst || $.isEmptyObject(rst))
                        return;

                    SelectData[0].Name = rst.Name;
                    model.com.renderProerty(DMSDevicePropertySource[model._type]);


                }, TypeSource_PROPERTY));

            });
            $("body").delegate(".device_property_status", "click", function () {
                var $this = $(this),
					Active = $this.attr("data-status"),
					SelectData = $com.table.getSelectionData($("#femi-ledger-property-tbody"), 'ID', DMSDevicePropertySource[model._type]);
                if (!SelectData || !SelectData.length) {
                    alert("至少选择一行数据！")
                    return;
                }
                $.each(SelectData, function (i, item) {
                    item.Active = Active == 1;
                });
                model.com.renderProerty(DMSDevicePropertySource[model._type]);
            });
            $("body").delegate("#femi-save-property", "click", function () {

                model.com.addProperty({
                    data: DMSDevicePropertySource[model._type],
                    type: model._type
                }, function (res) {
                    alert("保存成功!");
                    model.com.refresh();
                })

            });

            $("body").delegate("#femi-remove-property", "click", function () {
                var $this = $(this),
					SelectData = $com.table.getSelectionData($("#femi-ledger-property-tbody"), 'ID', DMSDevicePropertySource[model._type]);
                if (!SelectData || !SelectData.length) {
                    alert("至少选择一行数据！")
                    return;
                }
                $.each(SelectData, function (i, item) {
                    var _index = -1;
                    $.each(DMSDevicePropertySource[model._type], function (s_i, s_item) {
                        if (s_item.ID == item.ID)
                            _index = s_i;
                    });
                    DMSDevicePropertySource[model._type].splice(_index, 1);
                });
                model.com.renderProerty(DMSDevicePropertySource[model._type]);

            });
            $("body").delegate("#femi-refresh-property", "click", function () {

                model.com.refreshProperty(model._type);
            });

        },

        run: function () {
            model.com.getWorkShop({}, function (data) {

                $.each(data.list, function (i, item) {
                    TypeSource.WorkShopID.push({
                        name: item.WorkShopName,
                        value: item.ID,
                        far: null
                    })
                    $.each(item.LineList.aPSItem, function (l_i, l_item) {
                        TypeSource.LineID.push({
                            name: l_item.itemName,
                            value: l_item.ID,
                            far: item.ID
                        })
                    });

                });

            });


            model.com.getProperty({
                type: -1
            }, function (res) {
                if (!res)
                    return;
                var list = res.list,
					rst = [];

                $.each(list, function (i, item) {
                    DMSDevicePropertySource[i] = item;
                    if (TypeSource[PropertyField[i]] == undefined)
                        return true;
                    TypeSource[PropertyField[i]] = $com.table.getTypeSource(
						DMSDevicePropertySource[i], "ID", "Name",
						{
						    Active: true
						});
                });
                model.com.refresh();
            });

        },

        com: {
            get: function (data, fn, context) {
                var d = {
                    $URI: "/Device/All",
                    $TYPE: "get"
                };

                function err() {
                    $com.app.tip('获取失败，请检查网络');
                }

                $com.app.ajax($.extend(d, data), fn, err, context);
            },
            getProperty: function (data, fn, context) {
                var d = {
                    $URI: "/Device/Property",
                    $TYPE: "get"
                };

                function err() {
                    $com.app.tip('获取失败，请检查网络');
                }

                $com.app.ajax($.extend(d, data), fn, err, context);
            },
            getWorkShop: function (data, fn, context) {
                var d = {
                    $URI: "/WorkShop/All",
                    $TYPE: "get"
                };

                function err() {
                    $com.app.tip('获取失败，请检查网络');
                }

                $com.app.ajax($.extend(d, data), fn, err, context);
            },
            refresh: function () {
                model.com.get({}, function (res) {
                    if (res && res.list) {
                        DMSDeviceSource = res.list;

                        model.com.render(DMSDeviceSource);
                    }
                });
            },
            refreshProperty: function (type) {
                model.com.getProperty({
                    type: type
                }, function (res) {
                    if (res && res.list) {
                        DMSDevicePropertySource[type] = res.list;
                        TypeSource[PropertyField[type]] = $com.table.getTypeSource(
							DMSDevicePropertySource[type], "ID", "Name",
							{
							    Active: true
							});
                        model.com.renderProerty(DMSDevicePropertySource[type]);
                    }
                });
            },

            add: function (data, fn, context) {
                var d = {
                    $URI: "/Device/Save",
                    $TYPE: "post"
                };

                function err() {
                    $com.app.tip('提交失败，请检查网络');
                }

                $com.app.ajax($.extend(d, data), fn, err, context);
            },
            addProperty: function (data, fn, context) {
                var d = {
                    $URI: "/Device/PropertySave",
                    $TYPE: "post"
                };

                function err() {
                    $com.app.tip('提交失败，请检查网络');
                }

                $com.app.ajax($.extend(d, data), fn, err, context);
            },
            changeStatus: function (data, fn, context) {
                var d = {
                    $URI: "/Device/ChangeStatus",
                    $TYPE: "post"
                };

                function err() {
                    $com.app.tip('提交失败，请检查网络');
                }

                $com.app.ajax($.extend(d, data), fn, err, context);
            },



            render: function (list) {
                var _list = $com.util.Clone(list);
                $.each(_list, function (i, item) {
                    for (var p in item) {
                        if (!FORMATTRT[p])
                            continue;
                        item[p] = FORMATTRT[p](item[p]);
                    }
                    item.WID=i+1;
                });
                $("#femi-ledger-tbody").html($com.util.template(_list, HTML.TableLedgerItemNode));
            },
            renderProerty: function (list) {
                var _list = $com.util.Clone(list);
                $.each(_list, function (i, item) {
                    for (var p in item) {
                        if (!FORMATTRT_PROPERTY[p])
                            continue;
                        item[p] = FORMATTRT_PROPERTY[p](item[p]);
                    }
                    item.WID=i+1;
                });
                $("#femi-ledger-property-tbody").html($com.util.template(_list, HTML.TablePropertyItemNode));
            }
        }
    });

    model.init();


});